
package rectangle;

public class Rectangle {

    public static void main(String[] args) {
        // TODO code application logic here
        int width=5;  
        int height=10;  
        int area=width*height;  
        System.out.println("Area of rectangle="+area);
    }
    
}
